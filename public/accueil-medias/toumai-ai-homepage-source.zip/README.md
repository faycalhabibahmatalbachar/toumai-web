# Toumaï AI — Page d’accueil

Page d’accueil SaaS statique de Toumaï AI, avec un portrait éditorial original et quatre démonstrations animées :

1. puzzle auto-correctif ;
2. labyrinthe adaptatif ;
3. morpion stratégique ;
4. Puissance 4 stratégique.

## Ouvrir le site

Ouvrez `dist/index.html` dans un navigateur moderne. Aucun serveur, framework ou paquet supplémentaire n’est nécessaire.

## Structure

- `dist/index.html` — structure de la page ;
- `dist/styles.css` — direction artistique et mise en page responsive ;
- `dist/script.js` — navigation mobile et interactions du formulaire ;
- `dist/assets/` — illustration du hero ;
- `dist/animations/` — animations autonomes en HTML/CSS/JavaScript.

## Personnalisation

Les couleurs principales et les dimensions globales sont définies par des variables CSS au début de `dist/styles.css`. Chaque animation est autonome et peut aussi être ouverte séparément.
